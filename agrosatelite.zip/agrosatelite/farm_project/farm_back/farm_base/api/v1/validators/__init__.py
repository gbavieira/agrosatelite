from .cnpj import cnpj_validator
from .cpf import cpf_validator