import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  template: `<p routerLink="farm">Cadastrar</p>`,
})
export class DashboardComponent {}
